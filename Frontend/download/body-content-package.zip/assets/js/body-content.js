document.addEventListener('DOMContentLoaded', function() {
    const observer = new MutationObserver(function(mutations) {
        const toggleButton = document.getElementById('toggleRightPanel');
        if (toggleButton) {
            observer.disconnect(); // Disconnetti l'observer una volta trovato l'elemento
            const rightPanel = document.querySelector('.right-panel');
            const toggleIcon = toggleButton.querySelector('i');
            let isPanelOpen = true;

            function toggleRightPanel() {
                if (isPanelOpen) {
                    rightPanel.classList.add('right-panel-closed');
                    toggleIcon.classList.remove('ar-arrow-right-circle');
                    toggleIcon.classList.add('ar-arrow-left-circle');
                } else {
                    rightPanel.classList.remove('right-panel-closed');
                    toggleIcon.classList.remove('ar-arrow-left-circle');
                    toggleIcon.classList.add('ar-arrow-right-circle');
                }
                isPanelOpen = !isPanelOpen;
            }

            toggleButton.addEventListener('click', toggleRightPanel);

            function handleTableRowClick(event) {
                const row = event.target.closest('tr');
                if (row) {
                    toggleRightPanel();
                }
            }

            const tableRows = document.querySelectorAll('table tbody tr');
            if(tableRows){
                tableRows.forEach(row => {
                    row.addEventListener('click', handleTableRowClick);
                });
            }
        }
    });

    observer.observe(document.getElementById('content'), {
        childList: true,
        subtree: true
    });
});